#! /bin/bash
gedit /home/vagrant/Desktop/README.txt /home/vagrant/Desktop/License.txt
