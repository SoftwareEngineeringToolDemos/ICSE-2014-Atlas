Getting Started with Atlas

These following steps help in getting started with Atlas.


Step 0:

If you do not have a project imported to Eclipse, follow these steps (Importing an existing project):

1. From the main menu bar, select File > Import.... The Import wizard opens.
2. Select General > Existing Project into Workspace and click Next.
3. Choose either Select root directory or Select archive file and click the associated Browse to locate the directory or file containing the projects.
4. Under Projects select the project or projects which you would like to import.
5. Click Finish to start the import.


***Before following below steps, you must have a project imported to Eclipse.


Note:
In this VM, Eclipse is loaded with few sample projects which help you get started and gain experience with Atlas. Location of projects - /home/skataka/Desktop/workspace. Atlas has no restriction on size of projects but bigger projects take more time for mapping.


Step 1:
After loading projects to Eclipse, configure Atlas license information to start using Atlas:

1. First, obtain a license from Atlas website. You can find a free license here - http://www.ensoftcorp.com/atlas/lite/ and there are other types of license as well (Student license and Atlas Professional license).
2. Go to Eclipse, Click Atlas Menu Item and Click Atlas Smart View. Once Atlas Smart View is opened, you can find a hyperlink saying 'Please provide license information to start using Atlas'. Click this link.
3. Once a pop-up is opened, you can enter License Key, License email and hit 'Ok'. If the license information is correct, move onto next steps. (For more information on license, please look at License.txt file on Desktop).

Step 2:

After project(s) are imported to Eclipse and license information is entered, a project must be mapped to Atlas:
1. Click on Atlas menu item -> Project Map Settings menu item
2. On the left hand side, you will find list of projects imported to Eclipse. Click on desired project and hit 'Add'.
3. Atlas will index your source code, it will take a few seconds to a few minutes for most projects.


Step 3.1:

Once you are done with mapping a project to Atlas:
1. Click on Atlas menu item in Eclipse -> Atlas Smart View menu item.
2. Then click on a field to get a nice graph.
3. Atlas also maps graph elements to method declarations, files and variables.

To change the type of graph click on the drop-down item in the bottom left corner of Atlas Smart view and pick a different script. Have fun trying different scripts and clicking in different parts of your code. Clicking on various elements in the graphs takes you to that particular element in the specific file (which has the clicked element).


Step 3.2:
Atlas also has a Connection View menu item.

1. Click the Atlas -> Atlas Connection View menu item.
2. Atlas will index your source code, it will take a few seconds to a few minutes for most projects.
3. You can add files to 'root' pane and 'leaves' pane
4. Atlas Connection View gives you a nice graph showing how files in root pane are connected to files in 'leaves' pane. (They can be swaped with arrows present between the panes)


OR you can also follow -
To get started using Atlas watch these videos: http://www.ensoftcorp.com/atlas/getting-started-with-atlas/#AtlasSmartView and http://www.ensoftcorp.com/atlas/developers/

References:
1. http://help.eclipse.org/juno/index.jsp?topic=%2Forg.eclipse.platform.doc.user%2Ftasks%2Ftasks-importproject.htm
